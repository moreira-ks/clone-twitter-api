package km1.twitterApi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TwitterApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
